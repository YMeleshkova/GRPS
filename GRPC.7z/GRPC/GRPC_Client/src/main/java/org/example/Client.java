package org.example;

import com.example.grpc.GreetingServiceGrpc;
import com.example.grpc.GreetingServiceOuterClass;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;

import java.util.concurrent.TimeUnit;

/**
 @Author YMeleshkova
  */
public class Client {
    public static void main(String[] args) throws InterruptedException {
        ManagedChannel channel = ManagedChannelBuilder.forTarget("localhost:8080")
                .usePlaintext().build();
        GreetingServiceGrpc.GreetingServiceBlockingStub stub = GreetingServiceGrpc.newBlockingStub(channel);

        int currentValue = 0;
        for (int i = 0; i < 51; i++) {
            GreetingServiceOuterClass.HelloRequest request = GreetingServiceOuterClass.HelloRequest
                    .newBuilder()
                    .setFirstValue(0)
                    .setLastValue(30)
                    .build();
            GreetingServiceOuterClass.HelloResponse response = stub.greeting(request);
            currentValue = currentValue + response.getGreeting() + 1;
            System.out.println("currentValue: " + currentValue);
            TimeUnit.SECONDS.sleep(2);
        }
        channel.shutdownNow();
    }
}
