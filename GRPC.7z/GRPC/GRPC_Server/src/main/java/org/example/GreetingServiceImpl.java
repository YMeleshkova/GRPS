package org.example;

import com.example.grpc.GreetingServiceGrpc;
import com.example.grpc.GreetingServiceOuterClass;
import io.grpc.stub.StreamObserver;

import java.util.concurrent.ThreadLocalRandom;

public class GreetingServiceImpl extends GreetingServiceGrpc.GreetingServiceImplBase {
    @Override
    public void greeting(GreetingServiceOuterClass.HelloRequest request,
                         StreamObserver<GreetingServiceOuterClass.HelloResponse> responseObserver) {

        int randomNum = ThreadLocalRandom.current().nextInt(0, 30 + 1);

        System.out.println(randomNum);
        GreetingServiceOuterClass.HelloResponse response = GreetingServiceOuterClass.HelloResponse
                .newBuilder()
                .setGreeting(randomNum)
                .build();

        responseObserver.onNext(response);
        responseObserver.onCompleted();
    }
}
